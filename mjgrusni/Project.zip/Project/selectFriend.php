<!DOCTYPE=HTML>
<html>
	<head>
	</head>
	<body>
	<?php
		$oID = $_POST['originalID'];
		$friendID = $_POST['name'];
		echo $oID;
		echo $friendID;
	?>		
	</body>
</html>